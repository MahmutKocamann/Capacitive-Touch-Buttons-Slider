# Capacitive-Touch-mplementation-
Capacitive touch slider and button İmplementation using MSP430
